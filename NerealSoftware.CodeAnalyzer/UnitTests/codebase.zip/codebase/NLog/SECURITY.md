# Security Policy

## Supported Versions

Currently being supported with security updates.

| Version | Supported          |
| ------- | ------------------ |
| 4.6.x   | :white_check_mark: |
| 4.5.x   | :white_check_mark: |
| < 4.5   | :x:                |

## Reporting a Vulnerability

Please open an issue, without details. We will contact you then.  
