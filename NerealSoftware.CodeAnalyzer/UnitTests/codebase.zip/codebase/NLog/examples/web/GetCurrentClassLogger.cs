using System;
using System.Globalization;

using NLog;

class MyClass {
    static Logger logger = LogManager.GetCurrentClassLogger();
    
    // class members go here

}
